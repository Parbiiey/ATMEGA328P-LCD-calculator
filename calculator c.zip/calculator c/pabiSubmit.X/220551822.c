// define
#define F_CPU 16000000UL
#include <util/delay.h>
#include <avr/io.h>
#include <avr/interrupt.h>
#include <avr/eeprom.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>


#define RS			PC0
#define RdWr		PC1
#define EN			PC2
#define DataBUS		PORTB
#define CntrlBUS	PORTC

void lcdInit_4bits(void);
void LCDWrite_4bits(unsigned char wr);
void LCDCommand_4bits(unsigned char cmd);
volatile uint8_t timFlag = 0;


unsigned char keyValue=0;

uint16_t extractLastThreeDigits(uint32_t studNo) {
	return studNo % 1000;
}

void storeAnswer(uint16_t finalAnswr, uint16_t eepromAddress) {
	eeprom_write_word((uint16_t*)eepromAddress, finalAnswr);
}

volatile uint8_t lcdPowerFlag = 0;

void turnOnLCD(const char *message) {
	// Enable global interrupts
	sei();

	// Display message on the second line
	LCDCommand_4bits(0xC0); // Set cursor to the beginning of the second line
	while (*message) {
		LCDWrite_4bits(*message++);
	}

	// Set the LCD power flag
	lcdPowerFlag = 1;
}

uint8_t readBatteryPercentage() {
	// Set up ADC for single conversion on ADC2, 10 bits, AVREF = 5V
	ADMUX = (1 << REFS0) | (1 << MUX1);

	// Start ADC conversion
	ADCSRA |= (1 << ADSC);

	// Wait for conversion to complete
	while (ADCSRA & (1 << ADSC));

	// Read ADC result
	uint16_t adcValue = ADC;

	// Calculate battery percentage (assuming 3V is 100% and 1.5V is 0%)
	uint8_t batteryPercentage = ((adcValue - 307) * 100) / 307;

	return batteryPercentage;
}

void setupTimer1() {
	// Set normal mode (WGM13 = 0, WGM12 = 0, WGM11 = 0, WGM10 = 0)
	TCCR1A = 0;
	TCCR1B = 0;

	// Set prescaler to 1024
	TCCR1B |= (1 << CS12) | (1 << CS10);

	// Enable Timer/Counter 1 Overflow interrupt
	TIMSK1 |= (1 << TOIE1);
}
void setupTimer0() {
	// Set CTC mode (WGM01 = 2)
	TCCR0A |= (1 << WGM01);
	
	// Set prescaler to 1024
	TCCR0B |= (1 << CS02) | (1 << CS00);
	
	// Calculate and set the compare match value for a 3-second delay
	OCR0A = 234; // (F_CPU / (1024 * 1)) * 3 - 1
	
	// Enable Timer/Counter 0 Output Compare Match A interrupt
	TIMSK0 |= (1 << OCIE0A);
}
ISR(TIMER1_OVF_vect) {
	// If the LCD was powered off, clear the entire display
	if (!lcdPowerFlag) {
		LCDCommand_4bits(0x01); // Clear display command
	}

	// Reset the LCD power flag
	lcdPowerFlag = 0;
}

ISR(TIMER0_COMPA_vect) {
	// If the LCD was powered off, clear the entire display
	if (!lcdPowerFlag) {
		//LCD_Command_4bits(0x01); // Clear display command
	}

	// Reset the LCD power flag
	lcdPowerFlag = 0;
}

unsigned char units=0;
unsigned char tens=0; //14 (1 tens and 4 units)

unsigned char rcVal[16] = {'7', '4', '1', 'C', '8', '5', '2', '0', '9', '6', '3', '=', '+', '-', 'x', '/'};


unsigned char correctedKeyVal=0;

//4-bits mode functions-------------------------//
void LCDWrite_4bits(unsigned char wr)
{

	if (wr == '0') {
		return;
	}

	DataBUS = (DataBUS & 0x0F) | (wr & 0xF0);
	CntrlBUS |= (1 << RS); // RS=1 data mode
	CntrlBUS |= (1 << EN); // Enable writing to the LCD
	_delay_us(1);
	CntrlBUS &= ~(1 << EN); // Pull EN low after 1 us to finish the write cycle
	_delay_ms(1);            // Wait for the writing command to complete

	DataBUS = (DataBUS & 0x0F) | ((wr & 0x0F) << 4);
	CntrlBUS |= (1 << EN); // Enable writing to the LCD
	_delay_us(1);
	CntrlBUS &= ~(1 << EN); // Pull EN low after 1 us to finish the write cycle
	_delay_ms(2);            // Wait for the writing command to complete
}
	


void LCDCommand_4bits(unsigned char cmd)
{
	DataBUS= (DataBUS &0x0F)|(cmd & 0xF0);
	CntrlBUS &= ~(1<<RS); //RS LOW for command sending
	CntrlBUS |= (1<<EN); //Enable writing to the LCD
	_delay_us(1);
	CntrlBUS &= ~(1<<EN); //Pull EN low after 1 us to finish the write cycle
	_delay_us(200);//Wait for the writing command to complete
	
	DataBUS= (DataBUS & 0x0F)|((cmd & 0x0F)<<4);//send lower nibble
	CntrlBUS |= (1<<EN); //Enable writing to the LCD
	_delay_us(1);
	CntrlBUS &= ~(1<<EN); //Pull EN low after 1 us to finish the write cycle
	_delay_ms(2);//Wait for the writing command to complete
}

void lcdInit_4bits(void)
{
	_delay_ms(15); //wait for the LCD to power up
	LCDCommand_4bits(0x02);//return home
	LCDCommand_4bits(0x28);//Initializing 4-bit mode, 5x8 font
	LCDCommand_4bits(0x0C); //Display ON, cursor OFF
	
	LCDCommand_4bits(0x01);//clear screen
	_delay_ms(2);
	
	LCDCommand_4bits(0x06);//Auto increment cursor
	LCDCommand_4bits(0x80);//Force cursor at the beginning of the first line
	CntrlBUS &=~(1<<RdWr); //selecting to write to LCD
	
}
//--------------------------------------------------------
uint16_t finalAnswr = 0;

ISR(INT0_vect)
{
	cli();
	EIMSK &= ~(1 << INT0); // Disable External interrupt 0

	keyValue = ((PIND & 0xF0) >> 4);

	correctedKeyVal = rcVal[keyValue];
	units = correctedKeyVal % 10;
	tens = correctedKeyVal / 10;

	// Display each digit on the first row of the LCD
	LCDWrite_4bits('0' + tens);
	LCDWrite_4bits('0' + units);

	// Update the answer based on the entered digits (modify this part accordingly)
	finalAnswr = finalAnswr * 10 + correctedKeyVal;

	sei();
	EIMSK |= (1 << INT0); // Enable External interrupt 0
	EICRA |= (1 << ISC01) | (1 << ISC00); // Falling edge detection on INT0
}

void showMessage(const char *message) {
	// Assuming the first line of the LCD is already cleared, set cursor to the second line
	LCDCommand_4bits(0xC0);

	// Display the message on the second line
	while (*message) {
		LCDWrite_4bits(*message++);
	}
}

int main(void)
{
	setupTimer0();
	setupTimer1();
	uint32_t studNo = 220551822;
	uint16_t lastThreeDigits = extractLastThreeDigits(studNo);
	DDRB=0B11111111;//Define PORTB as output pins
	DDRC |= 0B00000111; //PC0, PC1 and PC2 as output pins 
	DDRD &= ~((1<<PD2)|(1<<PD7)|(1<<PD6)|(1<<PD5)|(1<<PD4)); //PD2: ext INT0, PD7-PD3 as inputs for data

	//Initialize ext INT0
	lcdInit_4bits();
	sei();//Enable interrupt globally
	EIMSK |= (1<<INT0);//Enable External interrupt 0
	EICRA |= (1<<ISC01)|(1<<ISC00) ; //Falling edge detection on INT0
	
    while (1) 
    {
		 storeAnswer(finalAnswr, lastThreeDigits);
		 sei();

		 while (!timFlag);
		 timFlag = 0;
		 
		  if (rcVal[1]) {
			  turnOnLCD("Powering ON");
				 // Read and display battery percentage and last saved answer for 4 seconds
				 for (uint8_t timer = 0; timer < 40; ++timer) {
					 // Read battery percentage through ADC2
					 uint8_t batteryPercentage = readBatteryPercentage();

					 // Display battery percentage on the first row of the LCD
					LCDCommand_4bits(0x80); // Move cursor to the beginning of the first line
					 printf("BP: %d%%", batteryPercentage);

					 // Read last saved answer from EEPROM
					 uint16_t prevSavedAnswer = eeprom_read_word((uint16_t *)lastThreeDigits);

					 // Display last saved answer on the right corner of the first line
					 LCDCommand_4bits(0xCF); // Move cursor to the right corner of the first line
					 printf("%d", prevSavedAnswer);

					 // Delay for 100ms (10 times for 4 seconds)
					 _delay_ms(100);
				 }
				  //LCD_Command_4bits(0x01);
			  // Wait for the timer flag to be set (indicating a 4-second delay)
			  while (!timFlag);

			  // Reset the timer flag
			  timFlag = 0;
		  }
	
		 // Display "Powering OFF" on the second line
		 showMessage("Powering OFF");

		 // Delay for 3 seconds
		 _delay_ms(3000);
		
    }
}



